package Paquete1;

public class coche1 {

    int numeroP=0;

    coche1(){
        System.out.println("constructor coche");
    }

        public void agregarP() {
        numeroP++;
        System.out.println("Se ha agregado una puerta.");
    }
        public void mostrarP() {
        System.out.println("La cantidad de puertas es: "+numeroP);

    }
}

