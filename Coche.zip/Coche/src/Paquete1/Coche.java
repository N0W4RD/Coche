package Paquete1;

public class Coche {


    public static void main(String[] args) {
        coche1 miCoche = new coche1();
        miCoche.agregarP();
        miCoche.mostrarP();
        miCoche.agregarP();
        miCoche.mostrarP();
        miCoche.agregarP();
        miCoche.mostrarP();
        miCoche.agregarP();
        miCoche.mostrarP();


    }}